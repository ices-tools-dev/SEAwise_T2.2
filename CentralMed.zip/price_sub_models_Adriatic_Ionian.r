rm(list=ls())
wd<-"C:\\Users\\Bitetto Isabella\\OneDrive - Coispa Tecnologia & Ricerca S.C.A.R.L\\H2020-SEAwise\\_____________WP2\\TASK 2.2\\reviewers"
setwd(wd)

data= read.table("data_fitting.csv",sep=";", header=TRUE)
n_iterations=30
library(dplyr)


# Selection of stock

species<-c("ARA181920")  # Options: "HKE1718", "HKE19","MUT19","MUT1718","DPS171819","ARS181920","ARA181920"


dir.create("FishPrice")
dir.create(paste("FishPrice/",species,sep=""))

data_temp= data[data$Species %in% species,]

data_temp=data_temp[data_temp$Value>0,]


Rev= data_temp[data_temp$Value >0 & data_temp$Variable == "revenues.landing",]
colnames(Rev)[5]="Revenues"
Land= data_temp[data_temp$Value >0 & data_temp$Variable == "landing.weight",]
colnames(Land)[5]="Landing"

library(dplyr)
land_data2=left_join(Rev[,c(1:3,5)],Land[,c(1:3,5)])



#land_data2=merge(Rev[,c(1:Landland_data2=merge(Rev[,c(1:3,5)],Land[,c(1:3,5)],by=c("Year","Fleet_segment","Species"))

#colnames(land_data2)[c(4,5)]=c("Revenues","Landing")


#land_data2=land_data[land_data$Revenues!=0,]

#land_data2[land_data2$Value!=0,]
land_data2$price<-0
land_data2$price<-as.numeric(land_data2$Revenues)/as.numeric(land_data2$Landing)

land_data2=land_data2[!is.na(land_data2$price),]

# Model 1
# 

strata=unique(land_data2$Fleet_segment)
i=1

epsilon=data.frame(epsilon=matrix(ncol=1,nrow=length(strata)))
epsilon$FS=""
epsilon$SPECIES=species
epsilon$MODEL=1
#epsilon$fore_points=0

for (i in c(1:length(strata))){
  
epsilon$FS[i]=as.character(strata[i])
land_data2_temp=land_data2[land_data2$Fleet_segment==strata[i],]
land_data2_temp$ratio=0
land_data2_temp$ratio[-1]=land_data2_temp$price[-1]/land_data2_temp$price[-nrow(land_data2_temp)]
land_data2_temp$ratio2=999
land_data2_temp$ratio2[-1]=(land_data2_temp$Land[-1]-land_data2_temp$Land[-nrow(land_data2_temp)])/land_data2_temp$Land[-1]

land_data2_temp$price_mod1=0

flee=data.frame(coeff=rep(NA,n_iterations),points=0, FS=strata[i], RMSE=0, iteration=0)

n=round(nrow(land_data2_temp)*5/6,0)

for (k in 1: n_iterations){
  # hindcasting only on 5/6 of the data

hind_indices=sample(2:nrow(land_data2_temp),n)

fore= which(!seq(1:nrow(land_data2_temp)) %in% hind_indices)

#epsilon[i,]$fore_points=paste(fore,collapse=",")

if(nrow(land_data2_temp)>5){
epsilon[i,]$epsilon=round(coefficients(lm((ratio-1)~ratio2+0,data=land_data2_temp[hind_indices,])),5)
}

land_data2_temp$price_mod1[-1]= land_data2_temp$price[-nrow(land_data2_temp)]*(1+epsilon[i,]$epsilon*land_data2_temp$ratio2[-1])


flee$coeff[k]= epsilon[i,]$epsilon
flee$RMSE[k] = sqrt(sum((as.numeric(land_data2_temp[fore,]$price)-land_data2_temp[fore,]$price_mod1)^2,na.rm=TRUE)/(length(land_data2_temp[fore,]$price)+1))
flee$FS=strata[i]
flee$iteration= k

}
epsilon$epsilon[i]=mean(flee$coeff,na.rm=TRUE)

epsilon$RMSE[i]=mean(flee$RMSE,na.rm=TRUE)


}
write.table(epsilon,paste("FishPrice/",species,"/Price_model1.csv",sep=""),sep=";",row.names=F)

# Model 2 (model 3 in Deliverable 2.2)

i=1

epsilon=data.frame(epsilon=matrix(ncol=1,nrow=length(strata)))
epsilon$FS=""
epsilon$SPECIES=species
epsilon$MODEL=2
#epsilon$fore_points=0

for (i in c(1:length(strata))){
  epsilon$FS[i]=strata[i]
  land_data2_temp=land_data2[land_data2$Fleet_segment==strata[i],]
  land_data2_temp$ratio=0
  land_data2_temp$ratio[-1]=land_data2_temp$price[-1]/land_data2_temp$price[-nrow(land_data2_temp)]
  land_data2_temp$ratio2=999
  land_data2_temp$ratio2[-1]=(land_data2_temp$Landing[-1]/land_data2_temp$Landing[-nrow(land_data2_temp)])
  
  land_data2_temp$price_mod2=0
  # hindcasting only on 2/3 of the data
  n=round(nrow(land_data2_temp)*5/6,0)
  
  flee=data.frame(coeff=rep(NA,n_iterations),points=0, FS=strata[i], RMSE=0, iteration=0)
  
 
  for (k in 1: n_iterations){
    
  hind_indices=sample(2:nrow(land_data2_temp),n)
  fore= which(!seq(1:nrow(land_data2_temp)) %in% hind_indices)
  
  #epsilon[i,]$fore_points=paste(fore,collapse=",")
  
  if (class(try(coefficients(nls((ratio)~(ratio2)^a,start=list(a=1),data=land_data2_temp[hind_indices,])),silent=TRUE))!="try-error") {
  epsilon[i,]$epsilon=round(coefficients(nls((ratio)~(ratio2)^a,start=list(a=1),data=land_data2_temp[hind_indices,]),silent=TRUE),3)
  } else {
    epsilon[i,]$epsilon=NA  
  }
  
  land_data2_temp$price_mod2[-1]= land_data2_temp$price[-nrow(land_data2_temp)]*(land_data2_temp$Landing[-1]/land_data2_temp$Landing[-nrow(land_data2_temp)])^epsilon[i,]$epsilon
  
  
  flee$coeff[k]= epsilon[i,]$epsilon
  flee$RMSE[k] = sqrt(sum((as.numeric(land_data2_temp[fore,]$price)-land_data2_temp[fore,]$price_mod2)^2,na.rm=TRUE)/(length(land_data2_temp[fore,]$price)+1))
  flee$FS=strata[i]
  flee$iteration= k
  
  }
  epsilon$epsilon[i]=mean(flee$coeff,na.rm=TRUE)
  epsilon$RMSE[i]=mean(flee$RMSE,na.rm=TRUE)
  
}

write.table(epsilon,paste("FishPrice/",species,"/Price_model2.csv",sep=""),sep=";",row.names=F)

# Model 3 (model 4 in Deliverable 2.2)


epsilon=data.frame(epsilon=matrix(ncol=1,nrow=length(strata)))
epsilon$FS=""
epsilon$SPECIES=species
epsilon$MODEL=3

#epsilon$fore_points<-0

for (i in c(1:length(strata))){
  
  epsilon$FS[i]=strata[i]
  land_data2_temp=land_data2[land_data2$Fleet_segment==strata[i],]
  land_data2_temp$ratio=0
  land_data2_temp$ratio[-1]=land_data2_temp$price[-1]/land_data2_temp$price[nrow(land_data2_temp)]
  
  land_data2_temp$price_mod3=0
  
  #land_data2_temp$ratio2=999
  #land_data2_temp$ratio2[-1]=(land_data2_temp$Ton[-1]/land_data2_temp$Ton[-nrow(land_data2_temp)])
  
  # hindcasting only on 2/3 of the data
  n=round(nrow(land_data2_temp)*5/6,0)
  flee=data.frame(coeff=rep(NA,n_iterations),points=0, FS=strata[i], RMSE=0, iteration=0)
  
  for (k in 1: n_iterations){
    
  hind_indices=sample(2:nrow(land_data2_temp),n)
  fore= which(!seq(1:nrow(land_data2_temp)) %in% hind_indices)
  
  #epsilon[i,]$fore_points=paste(fore,collapse=",")
  
  
  a_proxy= mean(log(land_data2_temp[hind_indices,]$ratio)/land_data2_temp[hind_indices,]$Landing,na.rm=TRUE)
  
  if (class(try(coefficients(nls(ratio~exp(a*Landing),start=list(a=a_proxy),data=land_data2_temp[hind_indices,])),silent=TRUE))!="try-error") {
    epsilon[i,]$epsilon=coefficients(nls(ratio~exp(a*Landing),start=list(a=a_proxy),data=land_data2_temp[hind_indices,]))
  } else {
    epsilon[i,]$epsilon=NA  
  }

  land_data2_temp$price_mod3[-1]= land_data2_temp$price[nrow(land_data2_temp)]*exp(epsilon[i,]$epsilon*land_data2_temp$Landing[-1])
  
  
  flee$coeff[k]= epsilon[i,]$epsilon
  flee$RMSE[k] = sqrt(sum((as.numeric(land_data2_temp[fore,]$price)-land_data2_temp[fore,]$price_mod3)^2,na.rm=TRUE)/(length(land_data2_temp[fore,]$price)+1))
  #flee$FS=strata[i]
  flee$iteration= k
  
  }
  
  epsilon$epsilon[i]=mean(flee$coeff,na.rm=TRUE)
  epsilon$RMSE[i]=mean(flee$RMSE,na.rm=TRUE)
  
  
  }

write.table(epsilon,paste("FishPrice/",species,"/Price_model3.csv",sep=""),sep=";",row.names=F)

# Model 4 (model 5 in Deliverable 2.2)



epsilon=data.frame(epsilon=matrix(ncol=1,nrow=length(strata)))
epsilon$FS=""
epsilon$SPECIES=species
epsilon$MODEL=4
#epsilon$fore_points=0
 
for (i in c(1:length(strata))){
  epsilon$FS[i]=strata[i]
  land_data2_temp=land_data2[land_data2$Fleet_segment==strata[i],]
 
  #land_data2_temp$ratio[-1]=land_data2_temp$price[-1]/land_data2_temp$price[nrow(land_data2_temp)]
  #land_data2_temp$ratio2=999
  #land_data2_temp$ratio2[-1]=(land_data2_temp$Ton[-1]/land_data2_temp$Ton[-nrow(land_data2_temp)])
  
  # hindcasting only on 2/3 of the data
  land_data2_temp$price_mod4=0
  
  #land_data2_temp$ratio2=999
  #land_data2_temp$ratio2[-1]=(land_data2_temp$Ton[-1]/land_data2_temp$Ton[-nrow(land_data2_temp)])
  
  # hindcasting only on 5/6 of the data
  
   flee=data.frame(coeff=rep(NA,n_iterations),points=0, FS=strata[i], RMSE=0, iteration=0)
  
  n=round(nrow(land_data2_temp)*5/6,0)
  
  for (k in 1: n_iterations){
    hind_indices=sample(2:nrow(land_data2_temp),n)
  fore= which(!seq(1:nrow(land_data2_temp)) %in% hind_indices)
  
  #epsilon[i,]$fore_points=paste(fore,collapse=",")
  
 
    epsilon[i,]$epsilon=mean(land_data2_temp$price[hind_indices],na.rm=TRUE)  
    
    land_data2_temp$price_mod4[-1]= epsilon[i,]$epsilon
    
        flee$coeff[k]= epsilon[i,]$epsilon
    flee$RMSE[k] = sqrt(sum((as.numeric(land_data2_temp[fore,]$price)-land_data2_temp[fore,]$price_mod4)^2,na.rm=TRUE)/(length(land_data2_temp[fore,]$price)+1))
    flee$FS=strata[i]
    flee$iteration= k
    
  }
  epsilon$epsilon[i]=mean(flee$coeff,na.rm=TRUE)
  epsilon$RMSE[i]=mean(flee$RMSE,na.rm=TRUE)
  
}

write.table(epsilon,paste("FishPrice/",species,"/Price_model4.csv",sep=""),sep=";",row.names=F)

# Model 5 (model 6 of deliverable 2.2, not by season)

epsilon=data.frame(epsilon=matrix(ncol=1,nrow=length(strata)))
epsilon$FS=""
epsilon$SPECIES=species
epsilon$MODEL=5
#epsilon$fore_points=0

for (i in c(1:length(strata))){
  
  epsilon$FS[i]=strata[i]
  land_data2_temp=land_data2[land_data2$Fleet_segment==strata[i],]
  land_data2_temp$ratio=0
  land_data2_temp$ratio[-1]=land_data2_temp$price[-1]/land_data2_temp$price[1]
  land_data2_temp$ratio2=999
  land_data2_temp$ratio2[-1]=(land_data2_temp$Landing[1]/land_data2_temp$Landing[-1])
  land_data2_temp$price_mod5=0
  
  # hindcasting only on 5/6 of the data
  n=round(nrow(land_data2_temp)*5/6,0)
  flee=data.frame(coeff=rep(NA,n_iterations),points=0, FS=strata[i], RMSE=0, iteration=0)
  
    for (k in 1: n_iterations){
    
  hind_indices=sample(2:nrow(land_data2_temp),n)
  fore= which(!seq(1:nrow(land_data2_temp)) %in% hind_indices)
  
  #epsilon[i,]$fore_points=paste(fore,collapse=",")
  
  
  if (class(try(coefficients(nls((ratio)~(ratio2)^a,start=list(a=0.5),data=land_data2_temp[hind_indices,])),silent=TRUE))!="try-error") {
    epsilon[i,]$epsilon=round(coefficients(nls((ratio)~(ratio2)^a,start=list(a=0.5),data=land_data2_temp[hind_indices,])),3)
  } else {
    epsilon[i,]$epsilon=NA  
  }


  land_data2_temp$price_mod5[-1]= land_data2_temp$price[1]*(land_data2_temp$Landing[1]/land_data2_temp$Landing[-1])^epsilon[i,]$epsilon
  
  
  flee$coeff[k]= epsilon[i,]$epsilon
  flee$RMSE[k] = sqrt(sum((as.numeric(land_data2_temp[fore,]$price)-land_data2_temp[fore,]$price_mod5)^2,na.rm=TRUE)/(length(land_data2_temp[fore,]$price)+1))
  flee$FS=strata[i]
  flee$iteration= k
  
}

epsilon$epsilon[i]=mean(flee$coeff,na.rm=TRUE)
epsilon$RMSE[i]=mean(flee$RMSE,na.rm=TRUE)

}

write.table(epsilon,paste("FishPrice/",species,"/Price_model5.csv",sep=""),sep=";",row.names=F)

# Binding the model results

results=list.files(path=paste("FishPrice/",species,sep=""),pattern="(model)",full.names = TRUE)

data_=read.table(results[1],sep=";",header=T) 

for (r in 2:length(results)){
 data2=read.table(results[r],sep=";",header=T) 
 data_=rbind(data_,data2) 
}





land_data2_tempp=land_data2[1,]
land_data2_tempp$price_Mod1=0
land_data2_tempp$price_Mod2=0
land_data2_tempp$price_Mod3=0
land_data2_tempp$price_Mod4=0
land_data2_tempp$price_Mod5=0
#land_data2_tempp$price_Mod6=0
r=1
#data_$RMSE=0
#data_$points=0


for (r in 1:length(strata)){
  
  # Observed
  land_data2_temp=land_data2[land_data2$Fleet_segment==strata[r],]  
  if (nrow(land_data2_temp)>2){
  
  jpeg(paste("FishPrice/",paste(species,sep=""),"/graph",r,".jpg",sep=""),units="cm",width = 30,height=15,res=400)
  
 # data_[data_$FS==strata[r],]$points = nrow(land_data2_temp)
  
plot(land_data2_temp$Year,land_data2_temp$price, ylab="Price/kg (euro)",xlab="Year",main=paste(species, strata[r]),ylim=c(0,3*max(land_data2_temp$price)),pch=19,cex=1.8,col="black",cex.main=2.5,cex.axis=2,cex.lab=1.8)  
  
# Model 1
  
data_temp=data_[data_$MODEL==1 & data_$FS==strata[r],] 
land_data2_temp$price_Mod1=0
land_data2_temp$price_Mod1[-1]=land_data2_temp$price[-nrow(land_data2_temp)]*(1+data_temp$epsilon*(land_data2_temp$Landing[-1]-land_data2_temp$Landing[-nrow(land_data2_temp)])/land_data2_temp$Landing[-1])

land_data2_temp$price_Mod1[1]=NA
lines(land_data2_temp$Year,land_data2_temp$price_Mod1,col="green",lwd=4)  

# RMSE 
 #fore=as.numeric(str_split(data_[data_$MODEL==1 & data_$FS==strata[r],]$fore_points,",")[[1]])
data_[data_$MODEL==1 & data_$FS==strata[r],]$RMSE=sqrt(sum((land_data2_temp$price-land_data2_temp$price_Mod1)^2,na.rm=TRUE)/(length(land_data2_temp$price)+1)) 


# Model 2


data_temp=data_[data_$MODEL==2 & data_$FS==strata[r],] 
land_data2_temp$price_Mod2=0
land_data2_temp$price_Mod2[-1]=land_data2_temp$price[-nrow(land_data2_temp)]*(land_data2_temp$Landing[-1]/land_data2_temp$Landing[-nrow(land_data2_temp)])^data_temp$epsilon
land_data2_temp$price_Mod2[1]=NA
lines(land_data2_temp$Year,land_data2_temp$price_Mod2,col="blue",lwd=4)  

# RMSE 
 data_[data_$MODEL==2 & data_$FS==strata[r],]$RMSE=sqrt(sum((land_data2_temp$price-land_data2_temp$price_Mod2)^2,na.rm=TRUE)/(length(land_data2_temp$price)+1)) 


# Model 4
data_temp=data_[data_$MODEL==3 & data_$FS==strata[r],] 
land_data2_temp$price_Mod3=0
land_data2_temp$price_Mod3[-1]=land_data2_temp$price[nrow(land_data2_temp)]*exp(land_data2_temp$Landing[-1]*data_temp$epsilon)
land_data2_temp$price_Mod3[1]=NA
lines(land_data2_temp$Year,land_data2_temp$price_Mod3,col="orange",lwd=4)  

# RMSE to be estimated on the forecast points
# fore=as.numeric(str_split(data_[data_$MODEL==1 & data_$FS==strata[r],]$fore_points,",")[[1]])
 data_[data_$MODEL==3 & data_$FS==strata[r],]$RMSE=sqrt(sum((land_data2_temp$price-land_data2_temp$price_Mod3)^2,na.rm=TRUE)/(length(land_data2_temp$price)+1)) 



# Model 5

data_temp=data_[data_$MODEL==4 & data_$FS==strata[r],] 
land_data2_temp$price_Mod4=data_temp$epsilon
#land_data2_temp$price_Mod3[-1]=land_data2_temp$price[-nrow(land_data2_temp)]*(land_data2_temp$Ton[-1]/land_data2_temp$Ton[-nrow(land_data2_temp)])^data_temp$epsilon
#land_data2_temp$price_Mod3[1]=NA
lines(land_data2_temp$Year,land_data2_temp$price_Mod4,col="black",lwd=3,lty="dotted")  

# RMSE to be estimated on the forecast points
data_[data_$MODEL==4 & data_$FS==strata[r],]$RMSE=sqrt(sum((land_data2_temp$price-land_data2_temp$price_Mod4)^2,na.rm=TRUE)/(length(land_data2_temp$price)+1)) 



# Model 5

data_temp=data_[data_$MODEL==5 & data_$FS==strata[r],] 
land_data2_temp$price_Mod5=0
land_data2_temp$price_Mod5[-1]=land_data2_temp$price[1]*(land_data2_temp$Landing[1]/land_data2_temp$Landing[-1])^data_temp$epsilon
land_data2_temp$price_Mod5[1]=NA
lines(land_data2_temp$Year,land_data2_temp$price_Mod5,col="turquoise",lwd=4)  

# RMSE to be estimated on the forecast points
# fore=as.numeric(str_split(data_[data_$MODEL==1 & data_$FS==strata[r],]$fore_points,",")[[1]])
data_[data_$MODEL==5 & data_$FS==strata[r],]$RMSE=sqrt(sum((land_data2_temp$price-land_data2_temp$price_Mod5)^2,na.rm=TRUE)/(length(land_data2_temp$price)+1)) 


land_data2_temp= land_data2_temp[,colnames(land_data2_temp) %in% c("Fleet_segment", "Species", "Year", "Revenues", "Landing",    "price", "price_Mod1", "price_Mod2", "price_Mod3", "price_Mod4", "price_Mod5")]
land_data2_tempp=rbind(land_data2_tempp,land_data2_temp)

legend("topleft",c("Observed","Model1","Model2","Model3","Model4", "Model5"),col=c("black","green","blue","orange","black","turquoise"),pch=c(19,NA,NA,NA,NA,NA),lty=c(NA,"solid","solid","solid","dotted","solid"),lwd=c(NA,4,4,4,3,4))


dev.off()

}
}

data_=data_[data_$RMSE>0,]

land_data2_tempp=land_data2_tempp[land_data2_tempp$Year>2013,]

write.table(land_data2_tempp[-1,],paste("FishPrice/",species,"/Price_fittings.csv",sep=""),sep=";",row.names=F)

selection=list()
ii=0

for (fl in strata){
  #fl="HRV_17_DTS_0612"
  ii=ii+1
  data_t=data_[data_$FS==fl,]
 
  tbi=data_t[which(data_t$RMSE==min(data_t$RMSE,na.rm=TRUE)),]
  if(nrow(tbi)>1){
  selection[[ii]]=tbi[1,]} else {
    selection[[ii]]= tbi}
    
  
  }

selection_tab=do.call(rbind,selection)

data_=data_[!is.na(data_$epsilon),]
write.table(data_,paste("FishPrice/",species,"/all_fittings.csv",sep=""),sep=";",row.names=F)

selection_tab=selection_tab[!is.na(selection_tab$epsilon),]
write.table(selection_tab,paste("FishPrice/",species,"/mod_selected.csv",sep=""),sep=";",row.names=F)


